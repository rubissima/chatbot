
import OpenAI from 'openai';
import 'dotenv';
import express from 'express';
import path from 'path';
import { Agent, setGlobalDispatcher } from 'undici';

const agent = new Agent({
    connect: {
        rejectUnauthorized: false
    }
})

setGlobalDispatcher(agent);

const app = express();
const port = 8080;

app.use(express.json());
app.use(express.static('public'));
app.use(express.urlencoded({ extended: true }));

// //Configure OpenAI
// const configuration = new openai.Configuration({
//     organization: process.env.OPENAI_ORG,
//     apiKey: process.env.OPENAI_API_KEY,
// });


const openaiapi = new OpenAI({
    apiKey: process.env.OPENAI_API_KEY,
});

app.get('/', (req, res) => {
    res.sendFile(path.join(__dirname, 'index.html'))
})

app.post('/chat', async (req, res) => {
    const messages = req.body.messages;
    const model = req.body.model;
    const temp = req.body.temp;

    const completion = await openaiapi.chat.completions.create ({
        model,
        messages,
        temperature: temp
    })

    res.status(200).json({ result: completion.choices });
})

app.listen(port, () => {
    console.log(`Example app listening on port ${port}`);
});